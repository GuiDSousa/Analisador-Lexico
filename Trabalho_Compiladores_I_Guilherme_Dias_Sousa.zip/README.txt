UNIVERSIDADE ESTADUAL DO SUDOESTE DA BAHIA - UESB
DISCIPLINA: COMPILADORES (2026.2) - PROF. JOSÉ CARLOS MARTINS OLIVEIRA
TRABALHO PRÁTICO DA I UNIDADE - ANALISADOR LÉXICO (MINI_PASCAL)
DISCENTE: GUILHERME DIAS SOUSA

ESTRUTURA DO PACOTE DE ENTREGA:
1. /Executavel/
   - MiniPascalLexer.exe (Aplicativo Windows Forms pronto para rodar com duplo clique no Windows).
2. /Documentacao/
   - guia_apresentacao.pdf e .txt (Roteiro cronometrado e perguntas prontas para a defesa oral).
   - documentacao_trabalho1.pdf e .txt (Relatório técnico completo e respostas às decisões de projeto).
   - documentacao_afd.pdf e .txt (Definição formal e tabela de transição do AFD).
   - gramatica_glc.pdf e .txt (Gramática Livre de Contexto G = (V,T,P,S) formalizada).
   - diagrama_afd.png (Diagrama gráfico ilustrativo dos estados do autômato).
3. /Testes/
   - 5 arquivos de entrada (.txt) e 5 arquivos de saída correspondentes gerados pelo analisador.
4. /CodigoFonte/
   - Projeto C# .NET 10.0 Windows Forms completo e ricamente comentado.
